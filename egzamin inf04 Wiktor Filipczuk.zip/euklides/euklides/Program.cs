﻿internal class Program
{
    private static void Main(string[] args)
    {
        Console.WriteLine("Podaj a:");
        int a = Convert.ToInt32(Console.ReadLine());

        Console.WriteLine("Podaj b:");
        int b = Convert.ToInt32(Console.ReadLine());

        while (a != b)
        {
            if (a > b)
            {
                a = a - b;
            }
            else
            {
                b = b - a;
            }
        }

        Console.WriteLine($"NWD {a}");
    }
}